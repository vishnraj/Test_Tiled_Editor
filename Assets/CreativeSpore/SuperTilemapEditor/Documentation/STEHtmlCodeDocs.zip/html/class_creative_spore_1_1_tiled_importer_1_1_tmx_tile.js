var class_creative_spore_1_1_tiled_importer_1_1_tmx_tile =
[
    [ "TmxTile", "class_creative_spore_1_1_tiled_importer_1_1_tmx_tile.html#a044fe9db4c3dc90377b735bdb08666dc", null ],
    [ "Id", "class_creative_spore_1_1_tiled_importer_1_1_tmx_tile.html#ab8f1b87234239b9d125e308de78f0b84", null ],
    [ "Properties", "class_creative_spore_1_1_tiled_importer_1_1_tmx_tile.html#aee4f67cedea6633d96c4b6a43ab58580", null ]
];