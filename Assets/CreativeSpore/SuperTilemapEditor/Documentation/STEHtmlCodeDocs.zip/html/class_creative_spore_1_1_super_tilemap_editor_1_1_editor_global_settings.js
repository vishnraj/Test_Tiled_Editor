var class_creative_spore_1_1_super_tilemap_editor_1_1_editor_global_settings =
[
    [ "Color32ToInt", "class_creative_spore_1_1_super_tilemap_editor_1_1_editor_global_settings.html#a34589a2a4abeb837b558db0388a1f754", null ],
    [ "IntToColor32", "class_creative_spore_1_1_super_tilemap_editor_1_1_editor_global_settings.html#a1a9f1edae578677054762dff8b25fadb", null ],
    [ "TilemapColliderColor", "class_creative_spore_1_1_super_tilemap_editor_1_1_editor_global_settings.html#a9c805b75ddb1ae450940274c9b15aa54", null ],
    [ "TilemapGridColor", "class_creative_spore_1_1_super_tilemap_editor_1_1_editor_global_settings.html#ae4da136f1a89bb6b1a25e4628ad37823", null ]
];