var class_creative_spore_1_1_super_tilemap_editor_1_1_anim_brush_1_1_tile_anim_frame =
[
    [ "tileId", "class_creative_spore_1_1_super_tilemap_editor_1_1_anim_brush_1_1_tile_anim_frame.html#ad02b7aac011ad0ed7f27bb4e11e03fa7", null ],
    [ "UVOffset", "class_creative_spore_1_1_super_tilemap_editor_1_1_anim_brush_1_1_tile_anim_frame.html#a7e10eb34cb83676c98e75e4a6306738d", null ]
];