var _tilemap_8cs =
[
    [ "Tilemap", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap" ],
    [ "ENABLE_TILECHUNK_CACHE_DIC", "_tilemap_8cs.html#ad206f8e43f6a57b9ff5c79a0f7f9fb2b", null ],
    [ "e2DColliderType", "_tilemap_8cs.html#a502ec414b8280748c6df2a21e34eb90c", [
      [ "EdgeCollider2D", "_tilemap_8cs.html#a502ec414b8280748c6df2a21e34eb90ca2b4d8f58db96a6a7aaa5ae2fe3522367", null ],
      [ "PolygonCollider2D", "_tilemap_8cs.html#a502ec414b8280748c6df2a21e34eb90cafcaaf32b57495eb114de8fce6419c332", null ]
    ] ],
    [ "eColliderType", "_tilemap_8cs.html#a9bc01705db54daa857de1d02caa2a975", [
      [ "None", "_tilemap_8cs.html#a9bc01705db54daa857de1d02caa2a975a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "_2D", "_tilemap_8cs.html#a9bc01705db54daa857de1d02caa2a975a8cf93a3cf4b8ee9a975671c37039d549", null ],
      [ "_3D", "_tilemap_8cs.html#a9bc01705db54daa857de1d02caa2a975a38e0791348f0496a0cbf3c07b64afed1", null ]
    ] ],
    [ "eTileFlags", "_tilemap_8cs.html#af1ebdec70850f500f001744f347c4dcd", [
      [ "None", "_tilemap_8cs.html#af1ebdec70850f500f001744f347c4dcda6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Updated", "_tilemap_8cs.html#af1ebdec70850f500f001744f347c4dcdaff0a3b7f3daef040faf89a88fdac01b7", null ],
      [ "Rot90", "_tilemap_8cs.html#af1ebdec70850f500f001744f347c4dcdad5251a97af7b4036b4528a54405ea2ad", null ],
      [ "FlipV", "_tilemap_8cs.html#af1ebdec70850f500f001744f347c4dcda6bb80f3cd9096afc925e99bff51a505b", null ],
      [ "FlipH", "_tilemap_8cs.html#af1ebdec70850f500f001744f347c4dcdad682de7b2e824d3410c77bb9b80f5646", null ]
    ] ]
];