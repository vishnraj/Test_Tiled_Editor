var class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data =
[
    [ "TileData", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#a48db2d5fc0daf16e1457cf7781c5c4c7", null ],
    [ "TileData", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#abd8376adc6313e33842bb00f32840ed3", null ],
    [ "BuildData", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#a640a1567a7951db58bed182eb2c24436", null ],
    [ "SetData", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#a28f2b8d303b136063fdbbee4c7e34676", null ],
    [ "brushId", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#a9a10911946cba75c69468b0786787cf4", null ],
    [ "flipHorizontal", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#a75ce7793de873a8e945b57b890a45807", null ],
    [ "flipVertical", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#a30b41ff80541d608d917aef3f7b109be", null ],
    [ "rot90", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#af3313dd75c28e867d06461584607c6cb", null ],
    [ "tileId", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#a3cbb7e06e159ea4661bde133afb02d1d", null ],
    [ "IsEmpty", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#ad823afae0829ecd55f4327bd8f159f4d", null ],
    [ "Value", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html#aeac94ae605fd2b9acdd2191930eab25f", null ]
];