var _tileset_brush_8cs =
[
    [ "TilesetBrush", "class_creative_spore_1_1_super_tilemap_editor_1_1_tileset_brush.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_tileset_brush" ],
    [ "eAutotilingMode", "_tileset_brush_8cs.html#a956037daa239aa47344c81703fcec6cc", [
      [ "Self", "_tileset_brush_8cs.html#a956037daa239aa47344c81703fcec6ccaad6e7652b1bdfb38783486c2c3d5e806", null ],
      [ "Other", "_tileset_brush_8cs.html#a956037daa239aa47344c81703fcec6cca6311ae17c1ee52b36e68aaf4ad066387", null ],
      [ "Group", "_tileset_brush_8cs.html#a956037daa239aa47344c81703fcec6cca03937134cedab9078be39a77ee3a48a0", null ],
      [ "EmptyCells", "_tileset_brush_8cs.html#a956037daa239aa47344c81703fcec6ccad46c295f6a82a9b3aebf7b932181428d", null ],
      [ "TilemapBounds", "_tileset_brush_8cs.html#a956037daa239aa47344c81703fcec6cca7be93df673ab2b9cffb4593b7864cf40", null ]
    ] ]
];