var namespaces =
[
    [ "CreativeSpore", "namespace_creative_spore.html", "namespace_creative_spore" ]
];