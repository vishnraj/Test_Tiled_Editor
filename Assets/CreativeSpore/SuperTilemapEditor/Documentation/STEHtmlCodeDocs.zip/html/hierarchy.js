var hierarchy =
[
    [ "CreativeSpore.SuperTilemapEditor.Tileset.BrushContainer", "struct_creative_spore_1_1_super_tilemap_editor_1_1_tileset_1_1_brush_container.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.BrushTileGridControl", "class_creative_spore_1_1_super_tilemap_editor_1_1_brush_tile_grid_control.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.BrushUtil", "class_creative_spore_1_1_super_tilemap_editor_1_1_brush_util.html", null ],
    [ "Editor", null, [
      [ "CreativeSpore.SuperTilemapEditor.TilemapEditor", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_editor.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.TilemapGroupEditor", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_group_editor.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.TilesetBrushEditor", "class_creative_spore_1_1_super_tilemap_editor_1_1_tileset_brush_editor.html", [
        [ "CreativeSpore.SuperTilemapEditor.A2X2BrushEditor", "class_creative_spore_1_1_super_tilemap_editor_1_1_a2_x2_brush_editor.html", null ],
        [ "CreativeSpore.SuperTilemapEditor.AnimBrushEditor", "class_creative_spore_1_1_super_tilemap_editor_1_1_anim_brush_editor.html", null ],
        [ "CreativeSpore.SuperTilemapEditor.CarpetBrushEditor", "class_creative_spore_1_1_super_tilemap_editor_1_1_carpet_brush_editor.html", null ],
        [ "CreativeSpore.SuperTilemapEditor.RandomBrushEditor", "class_creative_spore_1_1_super_tilemap_editor_1_1_random_brush_editor.html", null ],
        [ "CreativeSpore.SuperTilemapEditor.RoadBrushEditor", "class_creative_spore_1_1_super_tilemap_editor_1_1_road_brush_editor.html", null ]
      ] ],
      [ "CreativeSpore.SuperTilemapEditor.TilesetEditor", "class_creative_spore_1_1_super_tilemap_editor_1_1_tileset_editor.html", null ]
    ] ],
    [ "CreativeSpore.SuperTilemapEditor.EditorGlobalSettings", "class_creative_spore_1_1_super_tilemap_editor_1_1_editor_global_settings.html", null ],
    [ "EditorWindow", null, [
      [ "CreativeSpore.SuperTilemapEditor.AtlasEditorWindow", "class_creative_spore_1_1_super_tilemap_editor_1_1_atlas_editor_window.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.AtlasPreviewWindow", "class_creative_spore_1_1_super_tilemap_editor_1_1_atlas_preview_window.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.TilePropertiesWindow", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_properties_window.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.TileSelectionWindow", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_selection_window.html", null ]
    ] ],
    [ "CreativeSpore.SuperTilemapEditor.GizmosEx", "class_creative_spore_1_1_super_tilemap_editor_1_1_gizmos_ex.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.IBrush", "interface_creative_spore_1_1_super_tilemap_editor_1_1_i_brush.html", [
      [ "CreativeSpore.SuperTilemapEditor.TilesetBrush", "class_creative_spore_1_1_super_tilemap_editor_1_1_tileset_brush.html", [
        [ "CreativeSpore.SuperTilemapEditor.A2X2Brush", "class_creative_spore_1_1_super_tilemap_editor_1_1_a2_x2_brush.html", null ],
        [ "CreativeSpore.SuperTilemapEditor.AnimBrush", "class_creative_spore_1_1_super_tilemap_editor_1_1_anim_brush.html", null ],
        [ "CreativeSpore.SuperTilemapEditor.RandomBrush", "class_creative_spore_1_1_super_tilemap_editor_1_1_random_brush.html", null ],
        [ "CreativeSpore.SuperTilemapEditor.RoadBrush", "class_creative_spore_1_1_super_tilemap_editor_1_1_road_brush.html", [
          [ "CreativeSpore.SuperTilemapEditor.CarpetBrush", "class_creative_spore_1_1_super_tilemap_editor_1_1_carpet_brush.html", null ]
        ] ]
      ] ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "CreativeSpore.SuperTilemapEditor.Tilemap", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.TilemapChunk", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.TilemapGroup", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_group.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.TileObjectBehaviour", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_object_behaviour.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.TileObjMesh", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_obj_mesh.html", null ]
    ] ],
    [ "CreativeSpore.SuperTilemapEditor.TilemapChunk.OnTilePrefabCreationData", "struct_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk_1_1_on_tile_prefab_creation_data.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.Parameter", "class_creative_spore_1_1_super_tilemap_editor_1_1_parameter.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.ParameterContainer", "class_creative_spore_1_1_super_tilemap_editor_1_1_parameter_container.html", null ],
    [ "PropertyAttribute", null, [
      [ "CreativeSpore.SuperTilemapEditor.SortingLayerAttribute", "class_creative_spore_1_1_super_tilemap_editor_1_1_sorting_layer_attribute.html", null ]
    ] ],
    [ "PropertyDrawer", null, [
      [ "CreativeSpore.SuperTilemapEditor.SortingLayerPropertyDrawer", "class_creative_spore_1_1_super_tilemap_editor_1_1_sorting_layer_property_drawer.html", null ]
    ] ],
    [ "CreativeSpore.SuperTilemapEditor.RandomBrush.RandomTileData", "class_creative_spore_1_1_super_tilemap_editor_1_1_random_brush_1_1_random_tile_data.html", null ],
    [ "ScriptableObject", null, [
      [ "CreativeSpore.SuperTilemapEditor.Tileset", "class_creative_spore_1_1_super_tilemap_editor_1_1_tileset.html", null ],
      [ "CreativeSpore.SuperTilemapEditor.TilesetBrush", "class_creative_spore_1_1_super_tilemap_editor_1_1_tileset_brush.html", null ]
    ] ],
    [ "CreativeSpore.SuperTilemapEditor.ShortcutKeys", "class_creative_spore_1_1_super_tilemap_editor_1_1_shortcut_keys.html", null ],
    [ "STEditorStyles", "class_s_t_editor_styles.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.STEditorToolbars", "class_creative_spore_1_1_super_tilemap_editor_1_1_s_t_editor_toolbars.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.Tile", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.AnimBrush.TileAnimFrame", "class_creative_spore_1_1_super_tilemap_editor_1_1_anim_brush_1_1_tile_anim_frame.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TileColliderData", "struct_creative_spore_1_1_super_tilemap_editor_1_1_tile_collider_data.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TilemapChunk.TileColor32", "struct_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk_1_1_tile_color32.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TileData", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_data.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TileGridControl", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_grid_control.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TilemapDrawingUtils", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_drawing_utils.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TilemapUtils", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_utils.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TilePrefabData", "struct_creative_spore_1_1_super_tilemap_editor_1_1_tile_prefab_data.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TilePropertiesControl", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_properties_control.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TileSelection", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_selection.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TilesetControl", "class_creative_spore_1_1_super_tilemap_editor_1_1_tileset_control.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.TileView", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_view.html", null ],
    [ "CreativeSpore.TiledImporter.TmxImage", "class_creative_spore_1_1_tiled_importer_1_1_tmx_image.html", null ],
    [ "CreativeSpore.TiledImporter.TmxImporter", "class_creative_spore_1_1_tiled_importer_1_1_tmx_importer.html", null ],
    [ "CreativeSpore.TiledImporter.TmxLayer", "class_creative_spore_1_1_tiled_importer_1_1_tmx_layer.html", null ],
    [ "CreativeSpore.TiledImporter.TmxLayerTile", "class_creative_spore_1_1_tiled_importer_1_1_tmx_layer_tile.html", null ],
    [ "CreativeSpore.TiledImporter.TmxMap", "class_creative_spore_1_1_tiled_importer_1_1_tmx_map.html", null ],
    [ "CreativeSpore.TiledImporter.TmxTile", "class_creative_spore_1_1_tiled_importer_1_1_tmx_tile.html", null ],
    [ "CreativeSpore.TiledImporter.TmxTilemap", "class_creative_spore_1_1_tiled_importer_1_1_tmx_tilemap.html", null ],
    [ "CreativeSpore.TiledImporter.TmxTileProperty", "class_creative_spore_1_1_tiled_importer_1_1_tmx_tile_property.html", null ],
    [ "CreativeSpore.TiledImporter.TmxTileset", "class_creative_spore_1_1_tiled_importer_1_1_tmx_tileset.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.ToolbarControl", "class_creative_spore_1_1_super_tilemap_editor_1_1_toolbar_control.html", null ],
    [ "CreativeSpore.SuperTilemapEditor.ToolIcons", "class_creative_spore_1_1_super_tilemap_editor_1_1_tool_icons.html", null ],
    [ "CreativeSpore.TiledImporter.XMLSerializer", "class_creative_spore_1_1_tiled_importer_1_1_x_m_l_serializer.html", null ]
];