var dir_7f22afc085830684f8653b788f7cc888 =
[
    [ "Brush", "dir_c47ecf4fd775af23b17e0fb19e8cfac0.html", "dir_c47ecf4fd775af23b17e0fb19e8cfac0" ],
    [ "Editor", "dir_5fd4b458cd726f23f170e37db806a768.html", "dir_5fd4b458cd726f23f170e37db806a768" ],
    [ "EditorCompatibilityUtils.cs", "_editor_compatibility_utils_8cs.html", null ],
    [ "EditorGlobalSettings.cs", "_editor_global_settings_8cs.html", [
      [ "EditorGlobalSettings", "class_creative_spore_1_1_super_tilemap_editor_1_1_editor_global_settings.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_editor_global_settings" ]
    ] ],
    [ "SortingLayerAttribute.cs", "_sorting_layer_attribute_8cs.html", [
      [ "SortingLayerAttribute", "class_creative_spore_1_1_super_tilemap_editor_1_1_sorting_layer_attribute.html", null ]
    ] ],
    [ "Tilemap.cs", "_tilemap_8cs.html", "_tilemap_8cs" ],
    [ "TilemapChunk.cs", "_tilemap_chunk_8cs.html", [
      [ "TilemapChunk", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk" ],
      [ "TileColor32", "struct_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk_1_1_tile_color32.html", "struct_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk_1_1_tile_color32" ]
    ] ],
    [ "TilemapChunk_Collider.cs", "_tilemap_chunk___collider_8cs.html", [
      [ "TilemapChunk", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk" ]
    ] ],
    [ "TilemapChunk_Renderer.cs", "_tilemap_chunk___renderer_8cs.html", [
      [ "TilemapChunk", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk" ]
    ] ],
    [ "TilemapChunk_TileObjFactory.cs", "_tilemap_chunk___tile_obj_factory_8cs.html", [
      [ "TilemapChunk", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk" ],
      [ "OnTilePrefabCreationData", "struct_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk_1_1_on_tile_prefab_creation_data.html", "struct_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_chunk_1_1_on_tile_prefab_creation_data" ]
    ] ],
    [ "TilemapGroup.cs", "_tilemap_group_8cs.html", [
      [ "TilemapGroup", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_group.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_tilemap_group" ]
    ] ],
    [ "TileObjectBehaviour.cs", "_tile_object_behaviour_8cs.html", [
      [ "TileObjectBehaviour", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_object_behaviour.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_object_behaviour" ]
    ] ],
    [ "TileObjMesh.cs", "_tile_obj_mesh_8cs.html", [
      [ "TileObjMesh", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_obj_mesh.html", "class_creative_spore_1_1_super_tilemap_editor_1_1_tile_obj_mesh" ]
    ] ],
    [ "Tileset.cs", "_tileset_8cs.html", "_tileset_8cs" ]
];