var searchData=
[
  ['xmlserializable_2ecs',['XMLSerializable.cs',['../_x_m_l_serializable_8cs.html',1,'']]],
  ['xmlserializer',['XMLSerializer',['../class_creative_spore_1_1_tiled_importer_1_1_x_m_l_serializer.html',1,'CreativeSpore.TiledImporter.XMLSerializer'],['../class_creative_spore_1_1_tiled_importer_1_1_x_m_l_serializer.html#aaebb2d347161a901945f99c759c912b9',1,'CreativeSpore.TiledImporter.XMLSerializer.XMLSerializer()']]]
];
