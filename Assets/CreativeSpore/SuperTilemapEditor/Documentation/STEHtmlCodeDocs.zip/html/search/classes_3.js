var searchData=
[
  ['editorglobalsettings',['EditorGlobalSettings',['../class_creative_spore_1_1_super_tilemap_editor_1_1_editor_global_settings.html',1,'CreativeSpore::SuperTilemapEditor']]]
];
