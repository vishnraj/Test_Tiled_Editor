var class_creative_spore_1_1_tiled_importer_1_1_tmx_layer =
[
    [ "TmxLayer", "class_creative_spore_1_1_tiled_importer_1_1_tmx_layer.html#a9f72a17d16cac62153476f4f8f4fc836", null ],
    [ "Height", "class_creative_spore_1_1_tiled_importer_1_1_tmx_layer.html#adbd642a17441edf394e1894cf2a45cd2", null ],
    [ "Name", "class_creative_spore_1_1_tiled_importer_1_1_tmx_layer.html#af27cc257d1e74f2fa8ee71dc9e54f2d0", null ],
    [ "Opacity", "class_creative_spore_1_1_tiled_importer_1_1_tmx_layer.html#a91af2cd638cf65258bdcd7704f3b9a48", null ],
    [ "Tiles", "class_creative_spore_1_1_tiled_importer_1_1_tmx_layer.html#a6ee8949b9614860e1bfb850b4521cea6", null ],
    [ "Visible", "class_creative_spore_1_1_tiled_importer_1_1_tmx_layer.html#a20925577e3ee9dd2d022f09be14cd093", null ],
    [ "Width", "class_creative_spore_1_1_tiled_importer_1_1_tmx_layer.html#a2479f045cbb9bb81feab7d29ca51cf2b", null ]
];