var class_creative_spore_1_1_tiled_importer_1_1_tmx_tile_property =
[
    [ "Name", "class_creative_spore_1_1_tiled_importer_1_1_tmx_tile_property.html#abf64fb1aeee3d911e9e6b4b2eb519baa", null ],
    [ "Value", "class_creative_spore_1_1_tiled_importer_1_1_tmx_tile_property.html#aba681e5a502abb592656b92c1da14d98", null ]
];